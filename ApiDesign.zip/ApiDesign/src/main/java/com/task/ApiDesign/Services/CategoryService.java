package com.task.ApiDesign.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import com.task.ApiDesign.Entities.Category;
import com.task.ApiDesign.Repositories.CategoryRepository;

@Service
public class CategoryService
{
	private static final int DEFAULT_PAGE_SIZE = 2;
	@Autowired
	CategoryRepository categoryRepo;
	
	public Page<Category> getAllCategoryService(int page)
	{
		Pageable pageable = PageRequest.of(page, DEFAULT_PAGE_SIZE);
			return categoryRepo.findAll(pageable);
	}

	public Category createNewCategoryService(Category category)
	{
		return categoryRepo.save(category);
	}

	public Category getCategoryByIdService(int di)
	{
		return categoryRepo.findById(di).get();
	}

	public Category updateCategoryByIdService(int di, Category category)
	{
		Category foundCategory = categoryRepo.findById(di).get();
		if(foundCategory == null)
		{
			return null;
		}
		else
		{
			foundCategory.setCategoryName(category.getCategoryName());
			return categoryRepo.save(foundCategory);
		}
	}

	public String deleteCategoryByIdService(int di)
	{
		Category category = categoryRepo.findById(di).get();
		try {
			categoryRepo.delete(category);
		}
		catch(IllegalArgumentException iae)
		{
			return " No such Category found ";
		}
		catch(Exception e)
		{
			return " Something Went wrong ";
		}
		
		return " Category Deleted Successfully ";
	}

}
