package com.task.ApiDesign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDesignApplicationTests {

	@Test
	void contextLoads() {
	}

}
